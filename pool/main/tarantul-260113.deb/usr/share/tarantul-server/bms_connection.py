import asyncio
import logging
from typing import Final

from bleak import BleakScanner
from bleak.backends.device import BLEDevice
from bleak.exc import BleakError

from aiobmsble import BMSSample
from aiobmsble.bms.jikong_bms import BMS  # TODO: use the right BMS class for your device
import subprocess
import json
import logging

connected_clients = set()

# Configure logging
logging.basicConfig(level=logging.INFO)
logger: logging.Logger = logging.getLogger(__name__)

async def send_bms_data(d: list):
    data = json.dumps(d, ensure_ascii=False)
    dead = []
    for ws in list(connected_clients):
        try:
            await ws.send(data)    # websockets API
        except Exception:
            dead.append(ws)
    for ws in dead:
        connected_clients.discard(ws)

async def scan_bluetooth_network():
    results = await BleakScanner.discover(timeout=5, return_adv=True)
    candidates = []

    for address, (device, adv) in results.items():
        rssi = adv.rssi
        candidates.append((device, rssi))

    if not candidates:
        logger.info("No BMS found")
        return None

    # вибираємо найближчу BMS по RSSI
    best = max(candidates, key=lambda x: x[1])
    device, rssi = best

    return device.name


async def get_bms_data(dev_name: str) -> list[dict] | None:
    device = await BleakScanner.find_device_by_name(dev_name)
    if device is None:
        logger.error("Device '%s' not found.", dev_name)
        return None

    try:
        async with BMS(ble_device=device) as bms:
            sample = await bms.async_update()

            # --- універсальний доступ ---
            if isinstance(sample, dict):
                cell_voltages = sample.get("cell_voltages", [])
                cycles = sample.get("cycles", 0)
                cycle_capacity = sample.get("cycle_capacity", 0.0)
                current = sample.get("current", 0.0)
            else:
                cell_voltages = sample.cell_voltages
                cycles = sample.cycles
                cycle_capacity = sample.cycle_capacity
                current = sample.current

            values: list[dict] = []

            # voltage_cell1..14
            for idx, voltage in enumerate(cell_voltages[:14], start=1):
                values.append({f"voltage_cell{idx}": voltage})

            values.append({"cycle_count": cycles})
            values.append({"cycle_capacity": cycle_capacity})
            values.append({"current_charge": current})

            return values

    except BleakError as ex:
        logger.error("Failed to update BMS: %s", type(ex).__name__)
        return None
