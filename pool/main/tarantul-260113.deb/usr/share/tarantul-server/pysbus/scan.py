import asyncio
from bleak import BleakScanner

async def scan_bluetooth_network():
    results = await BleakScanner.discover(timeout=5, return_adv=True)
    candidates = []

    for address, (device, adv) in results.items():
        # device може бути None, тому перевіряємо
        if device and device.name and "BMS" in device.name.upper():
            rssi = adv.rssi
            candidates.append((device, rssi))
            print(f"{address} {device.name} RSSI={rssi}")

    if not candidates:
        print("No BMS found")
        return None

    # вибираємо найближчу BMS по RSSI
    best = max(candidates, key=lambda x: x[1])
    device, rssi = best
    print(f"Closest BMS: {device.address} RSSI={rssi}")

    return device.address