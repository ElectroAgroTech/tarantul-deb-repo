import asyncio
from bleak import BleakScanner

TARGET_UUID = "0000ffe0-0000-1000-8000-00805f9b34fb"

seen = set()
def on_detect(device, adv):
    if device.address in seen:
        return
    seen.add(device.address)
    print(f"{device.address} | name={device.name!r} | RSSI={adv.rssi} | uuids={adv.service_uuids}")
    if adv.service_uuids and TARGET_UUID in [u.lower() for u in adv.service_uuids]:
        print("  -> MATCH: JK-BMS service (FFE0)")

async def main():
    s = BleakScanner(detection_callback=on_detect)
    await s.start()
    await asyncio.sleep(8)
    await s.stop()

if __name__ == "__main__":
    asyncio.run(main())