import asyncio, platform, re, binascii, json, time
import argparse
from typing import Awaitable, Callable, Optional
from bleak import BleakScanner, BleakClient

JK_SVC = "0000ffe0-0000-1000-8000-00805f9b34fb"
FFE1 = "0000ffe1-0000-1000-8000-00805f9b34fb"
FFE2 = "0000ffe2-0000-1000-8000-00805f9b34fb"

HDR_TX = bytes([0xAA, 0x55, 0x90, 0xEB])
CMD_DEV_INFO = 0x97
CMD_BATT = 0x96
CHK97 = 0x11
CHK96 = 0x10

def cmd20(cmd: int, chk: int) -> bytes:
    # AA 55 90 EB | CMD 00 | 13*00 | CHK
    return HDR_TX + bytes([cmd, 0x00]) + bytes(13) + bytes([chk])

# - JK (RX) ---
HDR_RX = bytes([0x55, 0xAA, 0xEB, 0x90])

def hexs(b: bytes) -> str:
    return binascii.hexlify(b).decode()


def cut_frames(buf: bytearray):
    out, i = [], 0
    while True:
        j = buf.find(HDR_RX, i)
        if j < 0:
            if i: del buf[:i]
            break

        if len(buf) - j < 9:
            if j: del buf[:j]
            break

        ln2 = (buf[j+5] << 8) | buf[j+6]
        need2 = 4 + 1 + 2 + ln2 + 2  # hdr + type + len2 + payload + crc2
        if 0 <= ln2 <= 0x2000 and len(buf) - j >= need2:
            out.append(bytes(buf[j:j+need2]))
            i = j + need2
            continue

        ln1 = buf[j+5]
        need1 = 4 + 1 + 1 + ln1 + 2
        if 0 <= ln1 <= 0xA5 and len(buf) - j >= need1:
            out.append(bytes(buf[j:j+need1]))
            i = j + need1
            continue

        if j: del buf[:j]
        break

    if i: del buf[:i]
    return out

def len_and_payload(fr: bytes):
    assert fr.startswith(HDR_RX) and len(fr) >= 9
    ln2 = (fr[5] << 8) | fr[6]
    need2 = 4 + 1 + 2 + ln2 + 2
    if need2 == len(fr):
        return ln2, fr[7:7+ln2]
    ln1 = fr[5]
    need1 = 4 + 1 + 1 + ln1 + 2
    if need1 == len(fr):
        return ln1, fr[6:6+ln1]
    return max(0, len(fr)-8), fr[len(fr)-8:-2]

def pick_plausible_voltage(v_be: float, v_le: float, last_v: Optional[float]) -> Optional[float]:
    MIN_V, MAX_V = 5.0, 100.0
    candidates = []
    for v in (v_be, v_le):
        if MIN_V <= v <= MAX_V:
            penalty = 0.0
            if last_v is not None:
                if abs(v - last_v) > 15.0:
                    penalty += 100.0
                else:
                    penalty += abs(v - last_v) * 0.2
            candidates.append((penalty, v))
    if not candidates:
        return None
    candidates.sort(key=lambda x: x[0])
    return candidates[0][1]

def decode_batt_payload(p: bytes, last_good_v: Optional[float]):
    raw_be = int.from_bytes(p[0:2], "big")
    raw_le = int.from_bytes(p[0:2], "little")
    v_be = raw_be * 0.01226
    v_le = raw_le * 0.01226
    voltage = pick_plausible_voltage(v_be, v_le, last_good_v)

    cur = 0.0
    try:
        cur_raw = int.from_bytes(p[2:4], "big", signed=True)
        cur = round(cur_raw * 0.1, 1)
        if abs(cur) > 300.0:
            cur = 0.0
    except Exception:
        cur = 0.0

    soc = None
    for i in range(15, min(len(p), 60)):
        b = p[i]
        if 0 <= b <= 100:
            soc = int(b)
            break

    out = {}
    if voltage is not None:
        out["voltage"] = round(voltage, 3 if voltage < 10 else 2)
    if soc is not None:
        out["soc"] = soc
    out["current"] = cur
    return out

MAC_RE = re.compile(r"^([0-9A-Fa-f]{2}:){5}[0-9A-Fa-f]{2}$")

async def pick_target(uuid: Optional[str], mac: Optional[str], name: Optional[str]):
    os_name = platform.system()
    if uuid:
        return uuid
    if os_name == "Linux" and mac and MAC_RE.fullmatch(mac):
        return mac

    devs = await BleakScanner.discover(timeout=6.0)
    best = None
    best_rssi = -999
    for d in devs:
        try:
            rssi = getattr(d, "rssi", -999) or -999
            uuids = [u.lower() for u in (getattr(d, "metadata", {}) or {}).get("uuids") or []]
            name_ok = name and (name.lower() in ((d.name or "").lower()))
            svc_ok  = JK_SVC in uuids
            if name_ok or svc_ok:
                if rssi > best_rssi:
                    best, best_rssi = d, rssi
        except Exception:
            pass

    if best:
        return best
    raise RuntimeError("JK-BMS (FFE0) не знайдено. Увімкни батарею і закрий офіційний JK-додаток.")

SendFn = Callable[[dict], Awaitable[None]]

async def run(send: Optional[SendFn] = None, interval_sec: float = 2.0,
              uuid: Optional[str] = None, mac: Optional[str] = None, name: Optional[str] = None):
    def emit(d: dict):
        if send is None:
            print(json.dumps(d, ensure_ascii=False))
            return asyncio.sleep(0)
        return send(d)

    backoff = 2.0
    last_good_v: Optional[float] = None
    last_emit_ts = 0.0

    while True:
        try:
            target = await pick_target(uuid, mac, name)
            async with BleakClient(target, timeout=25.0) as client:
                if not client.is_connected:
                    await emit({"type": "battery", "source": "jk-bms", "error": "not_connected"})
                    await asyncio.sleep(backoff); backoff = min(backoff*1.5, 30.0)
                    continue

                buf = bytearray()
                def on_notify(_h, data: bytes):
                    buf.extend(data)

                await client.start_notify(FFE1, on_notify)
                try:    await client.start_notify(FFE2, on_notify)
                except: pass

                # Трохи «розбудити»
                await asyncio.sleep(0.2)
                await client.write_gatt_char(FFE1, cmd20(CMD_DEV_INFO, CHK97), response=False)
                await asyncio.sleep(0.2)

                backoff = 2.0

                while True:
                    buf.clear()
                    await client.write_gatt_char(FFE1, cmd20(CMD_BATT, CHK96), response=False)

                    got = None
                    t0 = time.time()
                    while time.time() - t0 < 1.2:
                        await asyncio.sleep(0.15)
                        frames = cut_frames(buf)
                        if not frames:
                            continue
                        for fr in frames:
                            if not fr.startswith(HDR_RX) or len(fr) < 9:
                                continue
                            ftype = fr[4]
                            ln, payload = len_and_payload(fr)
                            if ftype == 0x01 and ln >= 2:
                                decoded = decode_batt_payload(payload, last_good_v)
                                if "voltage" in decoded:
                                    last_good_v = decoded["voltage"]
                                got = {
                                    "type": "battery",
                                    "source": "jk-bms",
                                    "decoded": decoded
                                }
                                if "soc" in decoded:
                                    got["battery"] = decoded["soc"]
                                break
                        if got:
                            break

                    now = time.time()
                    if got:
                        should_emit = (now - last_emit_ts > 0.4)
                        if not should_emit and last_good_v is not None and "voltage" in got["decoded"]:
                            if abs(got["decoded"]["voltage"] - last_good_v) > 0.1:
                                should_emit = True
                        if should_emit:
                            await emit(got)
                            last_emit_ts = now
                    else:
                        await emit({"type": "battery", "source": "jk-bms", "note": "no_new_frame"})

                    await asyncio.sleep(interval_sec)

        except Exception as e:
            await emit({"type": "battery", "source": "jk-bms", "error": str(e)})
            await asyncio.sleep(backoff)
            backoff = min(backoff*1.5, 30.0)

def main():
    p = argparse.ArgumentParser("JK BMS reader (robust)")
    p.add_argument("--uuid", help="macOS CoreBluetooth UUID")
    p.add_argument("--mac",  help="Linux MAC")
    p.add_argument("--name", help="Device name (опційно)")
    p.add_argument("--wait", type=float, default=2.0, help="інтервал опитування, сек")
    args = p.parse_args()
    asyncio.run(run(send=None, interval_sec=args.wait, uuid=args.uuid, mac=args.mac, name=args.name))

if __name__ == "__main__":
    main()