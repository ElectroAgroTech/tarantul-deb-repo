import requests
from requests.auth import HTTPDigestAuth

username = 'admin'
password = 'Concept-12'
url = 'http://192.168.1.200/LAPI/V1.0/Channel/0/Media/Video/Streams/DetailInfos'
headers = {'Content-Type': 'application/json'}

width_stream = 0
height_stream = 0

def setup_stream(width, height):
    width_stream = width
    height_stream = height
    payload = {"Num":2,"VideoStreamInfos":[{"ID":0,"Enabled":1,"VideoEncodeInfo":{"EncodeFormat":2,"Resolution":{"Width":1280,"Height":720},"BitRate":2048,"BitRateType":0,"FrameRate":25,"GOPType":0,"IFrameInterval":50,"ImageQuality":5,"SmoothLevel":5,"SVCMode":0,"SmartEncodeMode":0}},{"ID":1,"Enabled":1,"VideoEncodeInfo":{"EncodeFormat":1,"Resolution":{"Width":width_stream,"Height":height_stream},"BitRate":1024,"BitRateType":1,"FrameRate":15,"GOPType":0,"IFrameInterval":50,"ImageQuality":2,"SmoothLevel":1,"SVCMode":0,"SmartEncodeMode":0}}]}

    try:
        response = requests.put(url, json=payload, auth=HTTPDigestAuth(username, password), headers=headers)
        response.raise_for_status()
        print(f"Status Code: {response.status_code}")
        print(f"Response Body: {response.text}")
    except requests.exceptions.RequestException as e:
        print(f"An error occurred: {e}")