import threading
from network_signal_settings import ETHERNET_SETTINGS, RADIO_SETTINGS
from sbus_communication import read_sbus_data, get_channel, get_failsafe_status
from gps_handler import start_read_gps, read_gps_background, set_user_gps_preference
from camera_api import setup_stream
from bms_connection import get_bms_data, send_bms_data, connected_clients, scan_bluetooth_network
import time
import lgpio as GPIO
import asyncio
import websockets
import json
import logging

# Define the GPIO pins based on your setup
pin_left_motor_control = 12  # PWM Output
pin_right_motor_control = 18  # PWM Output
pin_bomba_a = 25  # Bomba A pin
pin_bomba_b = 16  # Bomba B pin
pin_front_mine_dropping = 23  # Mine Front
pin_rear_mine_dropping = 24  # Mine Rear
pin_drone_light = 22  # Infrared light pin

gpio_handle = GPIO.gpiochip_open(0)

lest_ws_msg = 0

logging.basicConfig(level=logging.INFO, filename="/var/log/tarantul_log.log", format="%(asctime)s %(levelname)s %(message)s")

GPIO.gpio_claim_output(gpio_handle, pin_left_motor_control)
GPIO.gpio_claim_output(gpio_handle, pin_right_motor_control)

# checking connection variables
connection_type = RADIO_SETTINGS.type


def setup():
    threading.Thread(target=read_sbus_data, daemon=True).start()

    GPIO.gpio_claim_output(gpio_handle, pin_bomba_b)
    GPIO.gpio_claim_output(gpio_handle, pin_bomba_a)
    GPIO.gpio_claim_output(gpio_handle, pin_front_mine_dropping)
    GPIO.gpio_claim_output(gpio_handle, pin_rear_mine_dropping)
    GPIO.gpio_claim_output(gpio_handle, pin_drone_light)

    threading.Thread(target=start_ws).start()
    threading.Thread(target=read_radio_signal).start()
    threading.Thread(target=run_bms_monitoring).start() # start bms theading for get bms data
    threading.Thread(target=read_gps_background, daemon=True).start() # Постійне читання GPS в фоні

# GET BMS and GET BMS data
def run_bms_monitoring():
    asyncio.run(bms_monitoring_task())

async def bms_monitoring_task():
    logging.info("Search Bluetooth device BMS...")
    dev_name = await scan_bluetooth_network()

    if not dev_name:
        logging.info("BMS not found...")
        await asyncio.sleep(30)
        return await bms_monitoring_task()

    # Циклічне опитування BMS
    while True:
        try:
            data = await get_bms_data(dev_name)
            if data:
                await send_bms_data(data)
            else:
                logging.info("Failed to read data BMS")
        except Exception as e:
            logging.error(f"Error in BMS monitoring loop: {e}")

        await asyncio.sleep(30)  # опитування кожні 30 секунд

#CONNECT WEBSOCKET TO CLIENT
async def handler(websocket):
    try:
        connected_clients.add(websocket)
    except NameError:
        pass

    global lest_ws_msg
    change_network(ETHERNET_SETTINGS)
    start_read_gps(websocket) # Тепер це просто асинхронна таска в поточному loop
    
    logging.info('Start websocket')
    try:
        while True:
            try:
                data_json = await websocket.recv()
            except websockets.ConnectionClosed as e:
                logging.info(f"WebSocket connection closed: {e}")
                motor_stop()
                change_network(RADIO_SETTINGS)
                break

            try:
                message = json.loads(data_json)
            except Exception as e:
                logging.error(f"Bad JSON received, skip. Error: {e} | Raw: {data_json!r}")
                continue

            if not isinstance(message, dict):
                logging.info(f"Unexpected message type: {type(message)}, skipping.")
                continue

            block_mine_dropping(pin_rear_mine_dropping)
            block_mine_dropping(pin_front_mine_dropping)

            # Перевірка нового типу подій
            msg_event = message.get("event")
            if msg_event == "drone_light":
                light_data = message.get("data", {})
                state = light_data.get("state")
                if state == "on":
                    GPIO.gpio_write(gpio_handle, pin_drone_light, 1)
                elif state == "off":
                    GPIO.gpio_write(gpio_handle, pin_drone_light, 0)
                continue

            msg_command = message.get("command")
            if msg_command == "set_gps_source":
                source = message.get("source", "auto")
                set_user_gps_preference(source)
                continue

            msg_type = message.get("type")
            if msg_type == "joystick":
                if connection_type == ETHERNET_SETTINGS.type:
                    drone_control(message.get("left"), message.get("right"))
                    lest_ws_msg = time.time()

            elif msg_type == "mine":
                if message.get("frontMine"):
                    drop_mine(pin_front_mine_dropping)
                if message.get("rearMine"):
                    drop_mine(pin_rear_mine_dropping)

            elif msg_type == "bomba":
                if message.get("bombA"):
                    drop_bomba(pin_bomba_a)
                else:
                    block_bomba(pin_bomba_a)

                if message.get("bombB"):
                    drop_bomba(pin_bomba_a)
                    drop_bomba(pin_bomba_b)
                else:
                    block_bomba(pin_bomba_b)

            elif msg_type == "quality":
                stream_value = message.get("stream1", "")

                # Stream
                if "1280x720" in stream_value:
                    setup_stream(1280, 720)
                elif "720x576" in stream_value:
                    setup_stream(720, 576)
                elif "640x360" in stream_value:
                    setup_stream(640, 360)
                elif "704x288" in stream_value:
                    setup_stream(704, 288)
                elif "352x288" in stream_value:
                    setup_stream(352, 288)

            elif msg_type == "gamepad":
                state = message.get("gamepad")
                if state == "disconnect":
                    logging.info("Gamepad disconnected -> switching to radio")
                    change_network(RADIO_SETTINGS)
                elif state == "connect":
                    logging.info("Gamepad connected -> switching to ethernet")
                    change_network(ETHERNET_SETTINGS)

    except Exception as e:
        logging.error(f"Exception occurred: {e}")
        change_network(RADIO_SETTINGS)
    finally:
        try:
            connected_clients.discard(websocket)
        except NameError:
            pass
        logging.info('Websocket closed')


async def start_websocket():
    async with websockets.serve(handler, "0.0.0.0", 8001):
        await asyncio.Future()


def start_ws():
    asyncio.run(start_websocket())


def drone_control(left_motor, right_motor):
    speed_left_motor = map_value(left_motor, ETHERNET_SETTINGS.min, ETHERNET_SETTINGS.max, 5, 75)
    speed_right_motor = map_value(right_motor, ETHERNET_SETTINGS.min, ETHERNET_SETTINGS.max, 5, 75)

    if 4 < speed_left_motor < 76 and 4 < speed_right_motor < 76:
        logging.debug(f"Motor Command -> LEFT: {speed_left_motor} | RIGHT: {speed_right_motor}")
        GPIO.tx_pwm(gpio_handle, pin_left_motor_control, 50, speed_left_motor)
        GPIO.tx_pwm(gpio_handle, pin_right_motor_control, 50, speed_right_motor)


def motor_stop():
    GPIO.tx_pwm(gpio_handle, pin_left_motor_control, 50, 40)
    GPIO.tx_pwm(gpio_handle, pin_right_motor_control, 50, 40)


def read_radio_signal():
    logging.info('Radio is connect')
    while True:
        # it's validation for security drone
        if time.time() - lest_ws_msg > 1 and connection_type == ETHERNET_SETTINGS.type:
            motor_stop()
            
        # Якщо підключення по радіо, і пульт вимкнений або втратив зв'язок 
        if connection_type == RADIO_SETTINGS.type and get_failsafe_status():
            logging.debug("Radio signal lost! Stopping motors.")
            motor_stop()
            
        left_signal = get_channel(0)
        right_signal = get_channel(1)
        left_value = map_value(
            left_signal,
            RADIO_SETTINGS.min,
            RADIO_SETTINGS.max,
            ETHERNET_SETTINGS.min,
            ETHERNET_SETTINGS.max
        )
        right_value = map_value(
            right_signal,
            RADIO_SETTINGS.min,
            RADIO_SETTINGS.max,
            ETHERNET_SETTINGS.min,
            ETHERNET_SETTINGS.max
        )
        
        # Передаємо управління лише якщо ми в радіо-режимі і сигнал є
        if connection_type == RADIO_SETTINGS.type and not get_failsafe_status():
            drone_control(left_value, right_value)
            read_mine()
            read_bomb()
            
        time.sleep(0.24)


def read_mine():
    drop_mine(pin_front_mine_dropping) if get_channel(2) == 1811 else block_mine_dropping(pin_front_mine_dropping)
    drop_mine(pin_rear_mine_dropping) if get_channel(3) == 1811 else block_mine_dropping(pin_rear_mine_dropping)


def read_bomb():
    bomb_position = get_channel(5)

    if bomb_position == 997:
        drop_bomba(pin_bomba_a)
        block_bomba(pin_bomba_b)
    elif bomb_position > 997:
        drop_bomba(pin_bomba_a)
        drop_bomba(pin_bomba_b)
    else:
        block_bomba(pin_bomba_a)
        block_bomba(pin_bomba_b)


def drop_mine(pin_mine):
    GPIO.gpio_write(gpio_handle, pin_mine, 0)


def block_mine_dropping(pin_mine):
    GPIO.gpio_write(gpio_handle, pin_mine, 1)


def drop_bomba(pin_bomb):
    GPIO.gpio_write(gpio_handle, pin_bomb, 0)


def block_bomba(pin_bomb):
    GPIO.gpio_write(gpio_handle, pin_bomb, 1)


def change_network(network_settings):
    logging.info(f"Network is change: {network_settings.type}")
    global connection_type
    connection_type = network_settings.type


def map_value(x, in_min, in_max, out_min, out_max):
    return (x - in_min) * (out_max - out_min) // (in_max - in_min) + out_min

setup()
