from pymavlink import mavutil
import logging
import time

connection = mavutil.mavlink_connection('/dev/ttyACM0', baud=115200)


def check_connection():
    try:
        connection.wait_heartbeat()
        logging.info("MAVLink is connect")
        return True
    except Exception as e:
        logging.error(f"MAVLink connection is lost: {e}")
        return False


def arm_vehicle():
    logging.info("Sending arm command...")
    connection.mav.command_long_send(
        connection.target_system,
        connection.target_component,
        mavutil.mavlink.MAV_CMD_COMPONENT_ARM_DISARM,
        0,
        1,
        0, 0, 0, 0, 0, 0
    )
    logging.info("Waiting for arming confirmation...")
    while True:
        msg = connection.recv_match(type='HEARTBEAT', blocking=True)
        if msg.base_mode & mavutil.mavlink.MAV_MODE_FLAG_SAFETY_ARMED:
            logging.info("Vehicle is armed!")
            break
        time.sleep(1)


def override_rc_channel(channel_number, pwm_value):
    rc_channels = [65535]*18
    rc_channels[channel_number - 1] = pwm_value
    connection.mav.rc_channels_override_send(
        connection.target_system,
        connection.target_component,
        *rc_channels
    )
    logging.debug("MAVLink command is send")


def send_heartbeat():
    while True:
        try:
            connection.mav.heatbeat_send(
                mavutil.mavlink.MAV_TYPE_GCS,
                mavutil.mavlink.MAV_AUTOPILOT_INVALID,
                0, 0, 0
            )
            logging.debug("HEATBEAT send")
        except Exception as e:
            logging.error(f"HEATBEAT send is failed {e}")
        time.sleep(1)
