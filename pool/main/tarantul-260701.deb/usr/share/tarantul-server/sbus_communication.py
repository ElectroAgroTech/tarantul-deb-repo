# sbus_communication
from pysbus.sbus import SBUS
from pysbus.constants import SBUSConsts
from pysbus.serial_parser import SerialParser
import logging

port = '/dev/ttyAMA0'
baudrate = SBUSConsts.BAUD_RATE

stop_reading = False
is_ready = False
is_failsafe = False
last_valid_time = 0

sbus = SBUS(
    SerialParser(port, baudrate)
)
sbus.begin()

channels = [0] * SBUSConsts.NUM_CHANNELS


def read_sbus_data():
    global is_ready, is_failsafe, last_valid_time
    import time
    try:
        while not stop_reading:
            payload_ready, failsafe, lost_frame = sbus.read(channels)
            is_ready = payload_ready
            
            if payload_ready:
                last_valid_time = time.time()
                is_failsafe = failsafe
            
            # Якщо даних немає більше 1 секунди - вважаємо зв'язок втраченим
            if time.time() - last_valid_time > 1.0:
                is_failsafe = True
                
            # Якщо пульт вимкнений (failsafe) або втрачено багато кадрів (lost_frame) 
            # або минув таймаут (is_failsafe), ми ОБНУЛЯЄМО всі канали,
            # щоб двигуни зупинились на апаратному та програмному рівні
            if is_failsafe or lost_frame:
                for i in range(len(channels)):
                    # 992 на пульті RadioMaster Tx12 / FrSky часто відповідає центру стиків 
                    # Або ви можете скинути їх строго в 0. Ставимо 992 (нейтраль для більшості коліс)
                    # Якщо у вас 0 це нейтраль, поміняйте на 0
                    channels[i] = 992 
                
            # if payload_ready:
            #    logging.debug(f"Channels: {channels}")
            #    logging.debug(f"Fail-Safe Status: {failsafe}")
            #    logging.debug(f"Lost Frame Status: {lost_frame}")
 
    except KeyboardInterrupt:
        logging.info("SBUS reading stopped by User")

    finally:
        sbus.close()


def get_channel(num):
    return channels[num]


def is_payload_ready():
    return is_ready


def get_failsafe_status():
    return is_failsafe


def start_read_sbus():
    global stop_reading
    stop_reading = False


def stop_read_sbus():
    global stop_reading
    stop_reading = True
