import serial
import json
import asyncio
import logging
import math
import grpc
import starlink_grpc
import inspect
import time

# Налаштування порту
SERIAL_PORT = '/dev/ttyUSB0'
BAUD_RATE = 9600 # Стандартна швидкість для ATGM332D
STARLINK_IP = '192.168.100.1:9200'

latitude = None
longitude = None
user_gps_preference = 'auto'

def set_user_gps_preference(pref):
    global user_gps_preference
    if pref in ['auto', 'starlink', 'gps']:
        user_gps_preference = pref
        logging.info(f"Встановлено джерело GPS: {pref}")

def haversine(lat1, lon1, lat2, lon2):
    """
    Обчислює відстань між двома точками на Землі в кілометрах 
    за формулою гаверсинусів.
    """
    R = 6371.0 # Радіус Землі в км
    
    lat1_rad = math.radians(lat1)
    lon1_rad = math.radians(lon1)
    lat2_rad = math.radians(lat2)
    lon2_rad = math.radians(lon2)
    
    dlat = lat2_rad - lat1_rad
    dlon = lon2_rad - lon1_rad
    
    a = math.sin(dlat / 2)**2 + math.cos(lat1_rad) * math.cos(lat2_rad) * math.sin(dlon / 2)**2
    c = 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))
    
    return R * c

def get_starlink_location(channel):
    """
    Отримує координати зі Starlink.
    """
    try:
        sig = inspect.signature(starlink_grpc.location_data)
        
        if 'context' in sig.parameters:
            try:
                context = starlink_grpc.ChannelContext(target=STARLINK_IP)
                location = starlink_grpc.location_data(context=context)
            except AttributeError:
                location = starlink_grpc.location_data(context=channel)
        else:
            location = starlink_grpc.location_data(channel)
        
        if isinstance(location, dict):
            lat = location.get('latitude')
            lon = location.get('longitude')
        else:
            lat = getattr(location, 'latitude', None)
            lon = getattr(location, 'longitude', None)
            
        return lat, lon
        return lat, lon
    except Exception as e:
        logging.debug(f"Помилка отримання даних Starlink: {e}")
        return None, None

def nmea_to_decimal(nmea_coord, direction):
    """
    Перетворює координати з формату NMEA (градуси і хвилини) 
    у звичайні десяткові градуси.
    """
    if not nmea_coord:
        return 0.0
    
    # Широта має 2 цифри градусів (DDMM.MMMM), довгота - 3 цифри (DDDMM.MMMM)
    if direction in ['N', 'S']:
        degrees = float(nmea_coord[:2])
        minutes = float(nmea_coord[2:])
    else:
        degrees = float(nmea_coord[:3])
        minutes = float(nmea_coord[3:])
    
    decimal = degrees + (minutes / 60.0)
    
    # Для південної широти (S) та західної довготи (W) значення мають бути від'ємними
    if direction in ['S', 'W']:
        decimal *= -1
        
    return decimal

async def send_gps_to_client(websocket):
    """
    Асинхронна таска для відправки останніх відомих GPS даних конкретному клієнту
    """
    global latitude, longitude
    
    # Створюємо канал gRPC для Starlink (для кожного клієнта свій або краще один глобальний, але для простоти залишимо тут)
    sl_channel = grpc.insecure_channel(STARLINK_IP)
    
    try:
        while True:
            final_lat = None
            final_lon = None
            source = "None"
            
            # Отримуємо дані зі Starlink
            sl_lat, sl_lon = None, None
            if user_gps_preference in ['auto', 'starlink']:
                sl_lat, sl_lon = get_starlink_location(sl_channel)

            if user_gps_preference == 'gps':
                if latitude is not None and longitude is not None:
                    final_lat = latitude
                    final_lon = longitude
                    source = 'gps'
            elif user_gps_preference == 'starlink':
                if sl_lat is not None and sl_lon is not None:
                    final_lat = sl_lat
                    final_lon = sl_lon
                    source = 'starlink'
            else: # auto
                if latitude is not None and longitude is not None:
                    final_lat = latitude
                    final_lon = longitude
                    source = 'gps'
                    
                    if sl_lat is not None and sl_lon is not None:
                        dist = haversine(latitude, longitude, sl_lat, sl_lon)
                        if dist > 1.0:
                            logging.warning(f"Розбіжність GPS > 1км ({dist:.2f} км). Перемикання на дані Starlink.")
                            final_lat = sl_lat
                            final_lon = sl_lon
                            source = 'starlink'
                elif sl_lat is not None and sl_lon is not None:
                    final_lat = sl_lat
                    final_lon = sl_lon
                    source = 'starlink'
            
            # Якщо маємо хоч якісь дані - відправляємо клієнту
            if final_lat is not None and final_lon is not None:
                logging.debug(f"Відправка GPS ({source}): Lat={final_lat:.6f}, Lon={final_lon:.6f}")
                data_gps_json = json.dumps({
                    'latitude': final_lat,
                    'longitude': final_lon,
                    'source': source
                })
                
                try:
                    await websocket.send(data_gps_json)
                except Exception:
                    break # Якщо клієнт відключився, виходимо з циклу
            else:
                logging.debug("Немає валідних GPS даних ні з модуля, ні зі Starlink.")
                
            await asyncio.sleep(1) # Відправляємо/перевіряємо дані раз на секунду
    finally:
        if 'sl_channel' in locals():
            sl_channel.close()

def read_gps_background():
    """
    Функція яка неперервно читає дані з серійного порту і оновлює глобальні змінні.
    Має бути запущена в окремому потоці один раз.
    """
    global latitude, longitude
    
    while True:
        try:
            # Відкриваємо з'єднання з GPS-модулем
            ser = serial.Serial(SERIAL_PORT, BAUD_RATE, timeout=1)
            logging.info(f"GPS пристрій підключено на порту {SERIAL_PORT}")
            
            while True:
                # Читаємо рядок з порту і декодуємо його
                line = ser.readline().decode('ascii', errors='replace').strip()
                
                # Шукаємо рядок $GNGGA (або $GPGGA), який містить координати
                if line.startswith('$GNGGA') or line.startswith('$GPGGA'):
                    parts = line.split(',')
                    
                    if len(parts) >= 7 and parts[6] != '0' and parts[2] and parts[4]:
                        raw_lat = parts[2]
                        lat_dir = parts[3]
                        raw_lon = parts[4]
                        lon_dir = parts[5]
                        
                        # Оновлюємо глобальні змінні
                        latitude = nmea_to_decimal(raw_lat, lat_dir)
                        longitude = nmea_to_decimal(raw_lon, lon_dir)
                    else:
                        # Якщо втрачено фіксацію супутників
                        latitude = None
                        longitude = None
                            
        except serial.SerialException as e:
            logging.error(f"Помилка серійного порту GPS: {e}. Модуль відключено. Спроба через 5 сек...")
            latitude = None
            longitude = None
            time.sleep(5)
        except Exception as e:
            logging.error(f"Критична помилка в фоновому читанні GPS: {e}")
            latitude = None
            longitude = None
            time.sleep(5)
        finally:
            if 'ser' in locals() and ser.is_open:
                ser.close()

def start_read_gps(websocket):
    # Тепер ця функція лише запускає асинхронну відправку даних для конкретного клієнта
    asyncio.create_task(send_gps_to_client(websocket))
