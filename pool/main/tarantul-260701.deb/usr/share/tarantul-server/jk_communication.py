import subprocess
import json
import logging

connected_clients = set()

async def send_bms_data(d: list):
    data = json.dumps(d, ensure_ascii=False)
    dead = []
    for ws in list(connected_clients):
        try:
            await ws.send(data)    # websockets API
        except Exception:
            dead.append(ws)
    for ws in dead:
        connected_clients.discard(ws)


def get_bms_data(mac_address):
    try:
        result = subprocess.run(
            [
                '/usr/local/bin/jkbms',
                '-p', mac_address,
                '-P', 'JK02',
                '-c', 'getCellData',
                '-o', 'json'
            ],
            capture_output=True,
            text=True,
            timeout=30
        )

        if result.returncode == 0 and result.stdout:
            data = json.loads(result.stdout)
            voltages = [
                {key: data[key]}
                for key in sorted(data)
                if key.startswith("voltage_cell")
            ][:14]
            extra = [{key: data[key]} for key in ["cycle_count", "cycle_capacity", "current_charge"] if key in data]
            values = voltages + extra
            return values
        else:
            logging.error(f"jkbms STDOUT: {result.stdout}")
            logging.error(f"jkbms STDERR: {result.stderr}")
            return None

    except json.JSONDecodeError as e:
        logging.info(f"Error parse JSON: {e}")
        return None